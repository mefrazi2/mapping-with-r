# Let's check out what our current working directory is
getwd()

# Now let's set up our working directory. This will allow us to extract our data.
setwd("C:/Users/mfn2245/Desktop/mapping_w_r_data/")

# Double-check that your wd is correct
getwd()

# Install necessary packages for this demo
install.packages("sf")
install.packages("tmap")

# Load in packages by using the library() function
library(sf)
library(tmap)

# Pull in our .shp of Chicago Community Areas with 2021 average income data
chi_comm <- st_read("community_areas.shp")

# Let's checkout what our GCS/PCS might be
st_crs(chi_comm)

# Let's checkout our attribute table. A few of these will be important - namely "community" and "householdi".
View(chi_comm)

# Let's build a quick map using the first few variables in the data frame
plot(chi_comm)

# Plotting actual variables using the tmap package
tm_shape(chi_comm) + tm_polygons("householdi")

# What if we only wanted the outline of Chicago Community Areas?
tm_shape(chi_comm) + tm_borders()

# Within the function tm_fill, you can specify different color palettes.
tm_shape(chi_comm) + tm_fill("householdi", palette = "BuPu")

# Notice we didn't specify tm_borders(), so we ended up with no border outlines.

# Want to see all palettes? 
install.packages("shinyjs")
library(shinyjs)
tmaptools::palette_explorer() #whoa! So many

# We can also add titles! 
tm_shape(chi_comm) + tm_borders() + tm_fill("householdi", title = "2021 Average Household")

# Things start to get a bit cluttered here, so let's add our title outside of our map and position it to the upper-right.
tm_shape(chi_comm) + tm_fill("householdi", title = "2021 Average Income") + tm_borders() + tm_layout(legend.outside = TRUE, legend.outside.position = "right")

# Another cool output that's helpful is adding a histogram to show the distribution of your data. 
tm_shape(chi_comm) + tm_fill("householdi", title = "2021 Average Income", legend.hist = TRUE) + tm_borders() + tm_layout(legend.outside = TRUE, legend.outside.position = "right")

# Noticed we added the histogram as an argument `legend.hist` of the function `tm_fill`

# Okay, let's change the palette color one more time for our final map output! Choose one that's different than the one below. 
tm_shape(chi_comm) + tm_fill("householdi", palette = "BuPu", title = "2021 Average Income", legend.hist = TRUE) + tm_borders() + tm_layout(legend.outside = TRUE, legend.outside.position = "right")

# CHALLENGE 
# Want an additional challenge? Let's make our Chicago map display continous average HH income than discrete. 

# First install ggplot2, another popular R package
install.packages("ggplot2")
library(ggplot2)

# Now we will define the data as `chi_comm` and use `householdi` as the fill variable
ggplot(data = chi_comm, aes(fill = householdi)) + 
  geom_sf()

# Neat. But the colors seem to be in reverse.
# So let's fix those things
# By using the function `scale_fill_distiller`, we're able to change the color of the palette and reverse the direction of color by defining the argument as `1`.
ggplot(data = chi_comm, aes(fill = householdi)) + 
  geom_sf() + 
  scale_fill_distiller(palette = "RdPu", 
                       direction = 1)

# Now let's add some titles and data credits! The function `lab` can help us out
ggplot(data = chi_comm, aes(fill = householdi)) + 
  geom_sf() + 
  scale_fill_distiller(palette = "RdPu", 
                       direction = 1) + 
  labs(title = "Average Household Income 2021",
       caption = "Data source: 2021 average HH income, esri",
       fill = "Average HH Income in Chicago, 2021")

# Cool, but we don't really need the background lat & long (or at least not for this part)
# We can easily omit this the same way we used `tm_borders` by adding the function `theme_void()`
# Check out other background themes by `help(package = "ggplot2")`
ggplot(data = chi_comm, aes(fill = householdi)) + 
  geom_sf() + 
  scale_fill_distiller(palette = "RdPu", 
                       direction = 1) + 
  labs(title = "Average Household Income 2021",
       caption = "Data source: 2021 average HH income, esri",
       fill = "Average HH Income") + 
  theme_void()